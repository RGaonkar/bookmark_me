#import codecs

import nltk

from nltk.tokenize import *

import re

from nltk.corpus import stopwords

import csv 

from nltk.chunk import ne_chunk   #for extracting named entities


f = open("/media/34227B6E227B3448/projectBooKmarks/mid_sem/file1/phase1/link.csv")

item = f.read()

link_tok = nltk.word_tokenize(item)


